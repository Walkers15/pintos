#include "userprog/syscall.h"
#include "userprog/process.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <debug.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *);

void check_valid_pointer(void* ptr);

	void
syscall_init (void) 
{
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

	static void
syscall_handler (struct intr_frame *f) 
{
	// printf ("system call! %d\n", *(int*)f->esp);
	// printf("esp %d\n",  *(int *)f->esp);
 //  hex_dump((uintptr_t) f->esp, f->esp, 100, 1);

	int syscall_number = *(int *)f->esp; // syscallN 에서 esp에 System call number를 넣어준다

	switch (syscall_number) {
		case SYS_HALT: {
										 shutdown_power_off();
										 break;
									 }
		case SYS_EXIT: {
										 // exit (int status)
										 check_valid_pointer(f->esp + 4);

										 int status = *(int*) (f->esp + 4);
										 printf("%s: exit(%d)\n", thread_current()->name, status); 
										 thread_current()->exit_status = status;
										 thread_exit();
										 break;
									 }
		case SYS_EXEC: {
										 // pit_t exec (const char* file)

										 check_valid_pointer(f->esp + 4);

										 const char* instruction = *(const char**) (f->esp + 4);
										 // printf("EXEC!!! %s\n", instruction);
										 f->eax = process_execute(instruction); // Return Value 전달
										 break;
									 }
		case SYS_WAIT: {
										 // int wait(pid_t pid)
										 check_valid_pointer(f-> esp + 4);

										 tid_t pid = *(tid_t*) (f->esp + 4);
										 int status_code = process_wait(pid);
										 // printf("Wait DONE! status code: %d\n", status_code);
										 f->eax = status_code;
										 break;
									 }
		case SYS_CREATE: {
											 break;
										 }
		case SYS_REMOVE: {
											 break;
										 }
		case SYS_OPEN: {
										 break;
									 }
		case SYS_FILESIZE: {
												 break;
											 }
		case SYS_READ: {
										 // read(int fd, void * buffer, unsigned size)
										 check_valid_pointer(f-> esp + 4);
										 check_valid_pointer(f-> esp + 8);
										 check_valid_pointer(f-> esp + 12);

										 int fd = *(int*) (f-> esp + 4);
										 if (fd == 0) {
											 input_getc();
										 }
										 break;
									 }
		case SYS_WRITE: {
											// write (int fd, const void *buffer, unsigned size)
											// syscall3(SYS_WRITE, fd, buffer, size)
											// printf("write FILE\n");
											check_valid_pointer(f->esp + 4);
											check_valid_pointer(f->esp + 8);
											check_valid_pointer(f->esp + 12);

											int fd = *(int*) (f->esp + 4);
											// printf("fd is %d\n", fd);
											if (fd == 1) {
												void* buffer = (void*) *(uintptr_t*)(f->esp + 8);
												unsigned size = *(unsigned *)(f->esp + 12);
												putbuf(buffer, size);
											}
											break;
										}
		case SYS_SEEK: {
										 break;
									 }
		case SYS_TELL: {
										 break;
									 }
		case SYS_FIBO: {
										 // printf("FIBO CALL\n");
										 check_valid_pointer(f->esp + 4);
										 int n = *(int*) (f->esp + 4);
										 f->eax = fibonacci(n);
										 // printf("%d %d\n", n, fibonacci(n));
										 break;
									 }
		case SYS_MAX_OF_FOUR_INT: {
																// printf("MAX OF FOUR INT CALL이다!\n");
																check_valid_pointer(f->esp + 4);
																check_valid_pointer(f->esp + 8);
																check_valid_pointer(f->esp + 12);
																check_valid_pointer(f->esp + 16);
																int a = *(int*) (f->esp + 4);
																int b = *(int*) (f->esp + 8);
																int c = *(int*) (f->esp + 12);
																int d = *(int*) (f->esp + 16);
																f->eax = max_of_four_int(a, b, c, d);
																// printf("MAX OF FOUR INT CALL %d\n", f->eax);
																break;
															}

	}
	// printf("EXIT!!!\n");
	// thread_exit ();
}

void check_valid_pointer(void* ptr) {
	if(is_user_vaddr(ptr) == false) {
		// System Call Handler 를 강제로 종료시킨다.
		// abnormal way로 종료되었으므로 exit code는 -1이다.
		printf("%s: exit(%d)\n", thread_current()->name, -1);
		thread_current()->exit_status = -1;
		thread_exit();
	}
}

int fibonacci(int n) {
	int num1 = 0;
	int num2 = 1;
	int result = 1;
	for (int i = 2; i < n; i++) {
		num1 = num2;
		num2 = result;
		result = num1 + num2;
	}
	return result;
}

int max_of_four_int(int a, int b, int c, int d) {
	int max_num = a;

	if (max_num < b) {
		max_num = b;
	}

	if (max_num < c) {
		max_num = c;
	}

	if (max_num < d) {
		max_num = d;
	}

	return max_num;
}
